#!/system/bin/sh

## Example
#$ export VAR=/home/me/mydir/file.c
#$ export DIR=${VAR%/*}
#$ echo "${DIR}"
#/home/me/mydir
#$echo "${VAR##*/}"
#file.c
#To avoid dependency with basename and dirname

export PATH=/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin:$PATH
export ANDROID_DATA=/data
export ANDROID_ROOT=/system

VER=6
THIS_FULL_PATH=$0
THIS_DIR=${THIS_FULL_PATH%/*}
ROOT_DONE=$THIS_DIR/root_done
POSTROOT_LOG_TXT=$THIS_DIR/postroot_log.txt
POSTROOT_DONE=$THIS_DIR/postroot_done
KENVIRON_FILE=$THIS_DIR/kenviron
KRPR=_krpr
GREP=/system/bin/grep

# import environments
if [ -f "$KENVIRON_FILE" ]; then
	. $KENVIRON_FILE
fi

/system/bin/restorecon -R /data/*
/system/bin/restorecon -RF /data

fix_grep_location() {
	if [ -f "./grep" ]; then
		GREP=./grep
		return
	fi

	if [ -f "/system/bin/grep" ]; then
		rm -f /dev/grep
		cp /system/bin/grep /dev/grep
		GREP=/dev/grep
		return
	fi
	
	if [ -f "/sbin/grep" ]; then
		rm -f /dev/grep
		cp /sbin/grep /dev/grep
		GREP=/dev/grep
		return
	fi
}

func_get_my_dir() {
	while read line; do
		#echo $line
		echo $line | $GREP "mydir:" > /dev/null 2>&1
		if [ $? -eq 0 ]; then
			echo ${line:6}
			break
		fi
	done < $1
}

func_get_kd_dir() {
	while read line; do
		#echo $line
		echo $line | $GREP "kddir:" > /dev/null 2>&1
		if [ $? -eq 0 ]; then
			echo ${line:6}
			break
		fi
	done < $1
}

fun_play() {
	#----------------------------------------------------------
	echo "VER: $VER"
	echo "PATH: $PATH"
	echo "PWD: $PWD"
	echo "THIS_FULL_PATH: $THIS_FULL_PATH"
	echo "THIS_DIR: $THIS_DIR"
	#echo "BOOTCLASSPATH: $BOOTCLASSPATH"
	echo "GREP: $GREP"
	echo "KRCFG: $KRCFG"
	echo "MY_DIR: $MY_DIR"
	echo "KD_DIR: $KD_DIR"

	cat $MY_DIR/$KRPR > /dev/$KRPR
	chmod 0755 /dev/$KRPR
	/dev/$KRPR -k $KRCFG
	RET_KRPR=$?
	
	echo "$KRPR finished: $RET_KRPR"
}

func_fix_vars() {
	fix_grep_location
	chmod 0755 $GREP
	
	if [ -f "$1" ]; then
		KRCFG=$1
	else
		KRCFG=$THIS_DIR/krcfg.txt
	fi

	MY_DIR=$(func_get_my_dir $KRCFG)
	if [ -z "$MY_DIR" ]; then
		MY_DIR=$THIS_DIR
	fi

	KD_DIR=$(func_get_kd_dir $KRCFG)
	if [ -z "$KD_DIR" ]; then
		KD_DIR=$MY_DIR
	fi
	ROOT_DONE=$KD_DIR/root_done
	POSTROOT_LOG_TXT=$KD_DIR/postroot_log.txt
	POSTROOT_DONE=$KD_DIR/postroot_done
	
	if [ ! -f $MY_DIR/$KRPR ]; then
		echo "$MY_DIR/$KRPR not exist!"
	fi
}

func_touch() {
	chown 2000.2000 $1
	chmod 0777 $1
	chcon u:object_r:app_data_file:s0 $1
}


func_fix_vars $2

$MY_DIR/supolicy --live
$MY_DIR/supolicy --live "force shell;force s_init_shell;force init;force qti_init_shell;force untrusted_app"

rm -f $ROOT_DONE
rm -f $POSTROOT_LOG_TXT
rm -f $POSTROOT_DONE

touch $ROOT_DONE
func_touch $ROOT_DONE

touch $POSTROOT_LOG_TXT
func_touch $POSTROOT_LOG_TXT
fun_play $2 >> $POSTROOT_LOG_TXT 2>&1

touch $POSTROOT_DONE
echo 1 >> $POSTROOT_DONE
func_touch $POSTROOT_DONE
